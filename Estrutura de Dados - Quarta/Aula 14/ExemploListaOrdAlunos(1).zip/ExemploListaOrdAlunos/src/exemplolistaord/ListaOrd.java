//Ledón, 2024.

package exemplolistaord;

class ListaOrd<E extends Comparable<E>> {
    private int size;  //contador de objetos
    private Node head; //cabeça da lista ordenada

    //Cria uma Lista no estado vazia (construtor)
    public ListaOrd() {
        head = null;
        size = 0;
    }

    //Verifica se a lista está vazia
    public boolean isEmpty() {
        return (head == null);
    }

    public int size() {
        return this.size;
    }

    //Insere um elemento na lista ordenada
    public <E extends Comparable<E>> E insert(E x) {
        if (x == null || Runtime.getRuntime().freeMemory() < x.toString().length() + 1024) return null;
        Node novo = new Node();
        novo.setValue(x);  novo.setNext(null);  size++;        
        if (isEmpty() || x.compareTo((E) head.getValue()) < 0) { //lista vazia ou menor que o primeiro
            novo.setNext(head);
            head = novo;
        } else {
            Node aux = head;
            while (aux.getNext() != null && x.compareTo((E) aux.getNext().getValue()) > 0) 
                aux = aux.getNext();
            novo.setNext(aux.getNext());
            aux.setNext(novo);
        }
        return x;
    }

    //Retorna o conteúdo da lista ordenada
    public String toString() {
        if (!isEmpty()) {
            Node aux;
            aux = head;
            String saida = "";
            while (aux != null) {
                saida += aux.getValue().toString();
                aux = aux.getNext();
                if (aux != null) {
                    saida += ", ";  
                }
            }
            return "ListaOrd: [" + saida + "]";
        } else {
            return "ListaOrd: []";
        }
    }

        public String toString2() {
        if (!isEmpty()) {
            Node aux;
            aux = head;
            String saida = "";
            while (aux != null) {
                saida += "   " + aux.getValue().toString();
                aux = aux.getNext();
                if (aux != null) {
                    saida += "\n";  
                }
            }
            return "ListaOrd: [\n" + saida + "\n]";
        } else {
            return "ListaOrd: []";
        }
    }

    //Remover um elemento da lista
    public <E extends Comparable<E>> E remove(E x) {
        if (isEmpty() || x == null || x.compareTo((E) head.getValue()) < 0) { 
            return null;  //se lista vazia, ou valor menor que o primeiro, ou x é nulo 
        } else {
            size--; //um objeto está sendo eliminado
            if (x.compareTo((E) head.getValue()) == 0) { //se for o primeiro elemento	
                Node temp = head;
                x = (E)head.getValue(); //para pegar todos os dados do objeto
                head = head.getNext(); //avançar o ponteiro head
                temp.setNext(null);
                return x; //x foi encontrado na cabeça
            } else {  //se for maior que o primeiro, então tentar achar a posição:
                Node antes = head, depois = head.getNext();
                while (depois != null && x.compareTo((E) depois.getValue()) > 0) {
                    antes = antes.getNext();  //mover simultaneamente os dois ponteiros
                    depois = depois.getNext();
                }
                if (depois != null && x.compareTo((E)depois.getValue()) == 0) {
                    antes.setNext(depois.getNext());  //encontrou o objeto x, caso geral
                    return (E)depois.getValue();  //x foi encontrado
                } else return null;  //não encontramos o objeto x					
            }
        }
    }

    //Buscar um objeto na lista e retornar a posição onde encontrou
    public int find(E x) {
        if (x == null) return -1; 
        //navegamos até o nó de interesse:
        Node aux = head;  int pos = 0;
        while (aux != null && x.compareTo((E) aux.getValue()) > 0) {
            aux = aux.getNext(); pos++;
        }
        //se achamos o elemento:
        if (aux != null && x.compareTo((E) aux.getValue()) == 0) {
            return pos;
        } else {
            return -1; //n?o encontramos o objeto x
        }
    }

    //Destruir (limpar) a lista ordenada
    public void clear() {
        Node aux = head;
        while (aux != null) {
            Node tmp = aux;
            aux = aux.getNext();
            tmp.setNext(null); //para liberar memória
        }
        head = null;  size = 0;
    }
    
    public Object[] toArray() {
      //retorna um vetor com os objetos guardados na lista ordenada, o que poderá
      //ser útil para efetuar qualquer processamento em geral
      if(isEmpty())return null; //operação impossível se a fila estiver vazia
      Object vet[] = new Object[size];
      Node aux = head;
      for(int i=0; i<size; i++) {
          vet[i] = aux.getValue();
          aux = aux.getNext();
      }
      return vet;
    }

}
