package filaestaticasequencial;

public class Filme {
    private String titulo, diretor, genero, pais;
    private int ano;

   
}
