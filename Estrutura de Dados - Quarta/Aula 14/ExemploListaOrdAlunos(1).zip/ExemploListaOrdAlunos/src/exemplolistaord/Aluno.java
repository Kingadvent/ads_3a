
package exemplolistaord;

public class Aluno implements Comparable {
    private String rgm, nome;
    private int idade;
    private char sexo;

    public Aluno(String rgm, String nome, int idade, char sexo) {
        this.rgm = rgm;
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
    }

    @Override
    public String toString() {
        return "Aluno{" + "rgm=" + getRgm() + ", nome=" + getNome() + ", idade=" + getIdade() + ", sexo=" + getSexo() + '}';
    }

    public String getRgm() {
        return rgm;
    }

    public void setRgm(String rgm) {
        this.rgm = rgm;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }
        /*
    
    @Override
    public int compareTo(Object outro) {  
        //Para ter uma lista ordenada pelos nomes dos alunos:
        Aluno al = (Aluno)outro;
        if(getNome().compareToIgnoreCase(al.getNome()) < 0)return -1;
           else if (getNome().compareToIgnoreCase(al.getNome()) == 0)return 0;
             else return 1;
    }
    

    public int compareTo(Object outro) {  
        //Para ter uma lista ordenada pelos RGMs dos alunos:
        Aluno al = (Aluno)outro;
        if(getRgm().compareToIgnoreCase(al.getRgm()) < 0)return -1;
        else if (getRgm().compareToIgnoreCase(al.getRgm()) == 0)return 0;
        else return 1;
    }

*/
    public int compareTo(Object outro) {  
        //Para ter uma lista ordenada pelas idades dos alunos:
        Aluno al = (Aluno)outro;
        if(getIdade() < al.getIdade())return -1;
           else if (getIdade() == al.getIdade())return 0;
             else return 1;
    }    
    

    
}
