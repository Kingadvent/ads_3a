package exemplolistaord;

public class ExemploListaOrd {

    public static void main(String[] args) {
        ListaOrd listaAlunos = new ListaOrd();
        listaAlunos.insert(new Aluno("8888", "Caio Silva", 54, 'M'));
        listaAlunos.insert(new Aluno("7777", "Roberto Led�n", 92, 'M'));
        listaAlunos.insert(new Aluno("6666", "Zoe Valdes", 47, 'M'));
        listaAlunos.insert(new Aluno("2222", "Amilton Alves", 29, 'M'));
        listaAlunos.insert(new Aluno("4444", "Ana Lopes", 26, 'F'));
        listaAlunos.insert(new Aluno("9999", "Juan Felipe", 87, 'M'));
        listaAlunos.insert(new Aluno("1111", "Renata Souza", 24, 'F'));
        listaAlunos.insert(new Aluno("3333", "Pedro Lima", 25, 'M'));
        System.out.println("\n\nLista de objetos da classe Aluno, em ordem crescente pelos nomes: \n" 
                + listaAlunos.toString2() );  
        
        //exemplo: um processamento geral: contar homens e mulheres:
        int qm=0, qf=0;
        Object vet[] = listaAlunos.toArray();
        for(int i=0; i < vet.length; i++) {
            Aluno alu = (Aluno)vet[i]; //convers?o de tipo
            if(alu.getSexo() == 'M') qm++; else qf++;
        }
        System.out.println("Quantidade de sexo M: " + qm);
        System.out.println("Quantidade de sexo F: " + qf);
        
    }
    
}



