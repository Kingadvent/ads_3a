package exemplolistaord;

public class ExemploListaOrd {

    public static void main(String[] args) {
        ListaOrd list = new ListaOrd();
        System.out.println( list.toString() );
        list.insert(10);
        list.insert(9);
        list.insert(2);
        list.insert(6);
        list.insert(5);
        list.insert(10);
        list.insert(25);
        list.insert(98);
        list.insert(55);
        list.insert(1);
        list.insert(14);
        System.out.println( "Lista ordenada inicialmente: \n" + list.toString() );
        
        int pos = list.find(9);
        if (pos != -1) System.out.println( "Encontramos o 9 na posição " +   pos );
            
        pos = list.find(10);
        if (pos != -1) System.out.println( "Encontramos o primeiro 10 na posição " +   pos );
            
        System.out.println( "\nEliminamos o primeiro " + list.remove(10) + ":");
        System.out.println( list.toString() );
        System.out.println( "Eliminamos o segundo " + list.remove(10) + ":");
        System.out.println( list.toString() );
        System.out.println( "Eliminamos o " + list.remove(25) + ":");
        System.out.println( list.toString() );
        System.out.println( "Eliminamos o " + list.remove(2)  + ":");
        System.out.println( list.toString() );
        System.out.println( "Eliminamos o " + list.remove(1)  + ":");
        System.out.println( list.toString() );
        System.out.println( "Eliminamos o " + list.remove(98)  + ":");
        System.out.println( list.toString() );
        list.clear();
        System.out.println( "\nEsvaziamos a lista (clear) e ficou: \n" + list.toString() );
        
        System.out.println("\nAgora vamos criar uma lista ordenada de objetos strings...");
        ListaOrd listn = new ListaOrd();
        System.out.println( "Inicialmente vazia: " + listn.toString() );
        listn.insert("Julio");
        listn.insert("Ana");
        listn.insert("Lucas");
        listn.insert("Betty");
        listn.insert("Jenildo");
        listn.insert("Kaio");
        listn.insert("Zoe");
        listn.insert("Amilton");
        System.out.println( listn.toString() );
     }
    
}
