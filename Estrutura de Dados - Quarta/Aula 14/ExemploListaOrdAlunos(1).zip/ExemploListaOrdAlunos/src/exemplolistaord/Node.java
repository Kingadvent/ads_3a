package exemplolistaord;

public class Node {
    private Object value;   //dado a ser armazenado no nodo
    private Node next;	   //refer?ncia para o pr�ximo nodo

    public Object getValue() {
        return value;
    }

    public void setValue(Object novovalor) {
        value = novovalor;
    }

    public Node getNext() {
        return next;
    }

    public void setNext(Node novoprox) {
        next = novoprox;
    }
}
