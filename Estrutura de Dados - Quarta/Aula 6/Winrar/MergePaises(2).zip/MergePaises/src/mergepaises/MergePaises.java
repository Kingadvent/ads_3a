package mergepaises;

public class MergePaises {

    String veta[] = { "Angola", "Chile", "Grécia", "Itália", "Moçambique", "Portugal",
                      "Rússia", "Suécia" };
    String vetb[] = { "Argentina", "Brasil", "Canadá", "Chile", "Dinamarca", "Espanha", 
                      "França", "Inglaterra", "Turquia", "Uruguai", "Zimbawe" };
    Stirng res[];
    
    public static void main(String[] args) {
       
    }
    
    public void mergePaises (String a[], String b[], String res[]) {
        int i=0, j=0, k=0;
        
        while() { //ciclo para decidir se pegar de a[]
                  //ou de b[] e adiciona em res[]
            
            
            k++;
        }
        
        while() { //ciclo para copiar os possíveis itens
                  //remanescentes que ficaram em a[]            
        }
        
        while() { //ciclo para copiar os possíveis itens
                  //remanescentes que ficaram em b[]            
        }
    }
    
}
